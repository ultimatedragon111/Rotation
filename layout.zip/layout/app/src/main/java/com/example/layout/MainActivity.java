package com.example.layout;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView1;
    private LinearLayout cardView1;
    private ImageView imageView11;
    private LinearLayout cardView2;

    private int image1 = 0;
    private int image6 = 0;

    ObjectAnimator objectAnimator1;
    ObjectAnimator objectAnimator2;
    ObjectAnimator objectAnimator3;
    ObjectAnimator objectAnimator4;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView1 = findViewById(R.id.imageView);
        cardView1 = findViewById(R.id.cardView1);

        imageView11 = findViewById(R.id.imageView11);
        cardView2 = findViewById(R.id.cardView2);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(image1 == 0) {
                    objectAnimator1 = ObjectAnimator.ofFloat(imageView1, "RotationY", 0f, 180f);
                    objectAnimator1.setDuration(1000);
                    objectAnimator2 = ObjectAnimator.ofFloat(imageView1, "alpha", 1f, 0.2f);
                    objectAnimator2.setStartDelay(500);
                    objectAnimator3 = ObjectAnimator.ofFloat(cardView1, "RotationY", 180f, 360f);
                    objectAnimator3.setDuration(1000);
                    objectAnimator4 = ObjectAnimator.ofFloat(cardView1, "alpha", 0f, 1f);
                    objectAnimator4.setStartDelay(500);
                    objectAnimator4.setDuration(1);
                    image1++;
                }else{
                    objectAnimator1 = ObjectAnimator.ofFloat(imageView1, "RotationY", 180f, 0f);
                    objectAnimator1.setDuration(1000);
                    objectAnimator2 = ObjectAnimator.ofFloat(imageView1, "alpha", 0.2f, 1f);
                    objectAnimator2.setStartDelay(500);
                    objectAnimator3 = ObjectAnimator.ofFloat(cardView1, "RotationY", 360f, 180f);
                    objectAnimator3.setDuration(1000);
                    objectAnimator4 = ObjectAnimator.ofFloat(cardView1, "alpha", 1f, 0f);
                    objectAnimator4.setStartDelay(500);
                    objectAnimator4.setDuration(1);
                    image1--;
                }
                AnimatorSet animatorSet = new AnimatorSet();
                animatorSet.playTogether(objectAnimator1,objectAnimator2,objectAnimator3,objectAnimator4);
                animatorSet.start();
            }
        });

       /* imageView11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(image1 == 0) {
                    objectAnimator1 = ObjectAnimator.ofFloat(imageView11, "RotationY", 0f, 180f);
                    objectAnimator1.setDuration(1000);
                    objectAnimator2 = ObjectAnimator.ofFloat(imageView11, "alpha", 1f, 0.2f);
                    objectAnimator2.setStartDelay(500);
                    objectAnimator3 = ObjectAnimator.ofFloat(cardView2, "RotationY", 180f, 360f);
                    objectAnimator3.setDuration(1000);
                    objectAnimator4 = ObjectAnimator.ofFloat(cardView2, "alpha", 0f, 1f);
                    objectAnimator4.setStartDelay(500);
                    objectAnimator4.setDuration(1);
                    image1++;
                }else{
                    objectAnimator1 = ObjectAnimator.ofFloat(imageView11, "RotationY", 180f, 0f);
                    objectAnimator1.setDuration(1000);
                    objectAnimator2 = ObjectAnimator.ofFloat(imageView11, "alpha", 0.2f, 1f);
                    objectAnimator2.setStartDelay(500);
                    objectAnimator3 = ObjectAnimator.ofFloat(cardView2, "RotationY", 360f, 180f);
                    objectAnimator3.setDuration(1000);
                    objectAnimator4 = ObjectAnimator.ofFloat(cardView2, "alpha", 1f, 0f);
                    objectAnimator4.setStartDelay(500);
                    objectAnimator4.setDuration(1);
                    image1--;
                }
                AnimatorSet animatorSet = new AnimatorSet();
                animatorSet.playTogether(objectAnimator1,objectAnimator2,objectAnimator3,objectAnimator4);
                animatorSet.start();
            }
        });*/
    }
}